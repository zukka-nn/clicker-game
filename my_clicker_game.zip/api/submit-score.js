
export default async function handler(req, res) {
  if (req.method === 'POST') {
    const { name, score } = req.body;

    // Contoh simpan ke memori (untuk testing). Produksi harus pakai DB.
    // Karena serverless function stateless, di Vercel harus DB beneran.
    // Di sini hanya contoh balikan response.

    res.status(200).json({ message: `Score received: ${name} - ${score}` });
  } else {
    res.status(405).json({ message: 'Method not allowed' });
  }
}
